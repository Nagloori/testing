const country = '[data-test="input-country"]'
const action = '[data-test="actions"]'
const reset = '[class="sc-gtssRu sc-dlnjPT gmjWml cuIYFB"]'



describe('List of countries visited and want to visit',()=>{

    it('lsit of countries visited', () => {
        cy.visit ('https://qa-test.accessfintech.com/')
        cy.contains('Countries').click()
        cy.url().should('include', '/countries')
        cy.wait(500)
        //selecting countries want to visit 
        cy.get(country).first().check() 
          .should('have.checked','checked')  
        cy.get(country).eq(5).first().check()
          .should('have.checked','checked')  
        cy.get(country).eq(8).first().check()
          .should('have.checked','checked')  

        cy.get(action).select('visited')
        cy.contains('Andorra').click()
        cy.get('h1')
          .should('include.text', 'Andorra')
        cy.contains('Set as want to visit').click({force:true})
        cy.contains('Home').click()

        
        
        cy.get(reset).eq(0).should('have.text','Reset').click()
     
        cy.get(reset).should('have.text','Reset').click()
        
       
    })
    
    
    


    
})